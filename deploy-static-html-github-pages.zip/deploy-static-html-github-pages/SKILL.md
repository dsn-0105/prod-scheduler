---
name: deploy-static-html-github-pages
description: Deploy a static single-file HTML application or static site to GitHub Pages. Use this skill when the user wants to publish a local HTML file or static front-end to a GitHub Pages URL with a GitHub Actions deployment workflow.
agent_created: true
---

# Deploy Static HTML to GitHub Pages

## When to Use

Use this skill when the user wants to:

- Publish a single-file HTML app (e.g., a self-contained production/order/scheduling system) to a public URL.
- Deploy a static site or front-end prototype from local files to GitHub Pages.
- Set up a repeatable GitHub Actions workflow that rebuilds the site on every push.

This skill assumes the static content already works locally and the user has a GitHub account.

## Overview

The workflow in this skill performs the following steps:

1. Inspect the local HTML/static files and ensure they are ready for deployment.
2. Create the GitHub Pages deployment workflow (`.github/workflows/deploy.yml`).
3. Initialize a local Git repository and configure the remote to point to the target GitHub repository.
4. Push the files to GitHub, handling Git Credential Manager (GCM) login when needed.
5. Configure the repository visibility and enable GitHub Pages with source set to **GitHub Actions**.
6. Verify the deployment by checking the Actions run and the public Pages URL.

## Step 1: Prepare Local Files

Before deploying, make sure the workspace contains the static files:

- `index.html` (or the entry-point HTML file).
- Optional supporting files: `README.md`, `.gitignore`, `.nojekyll`.

If the project is a single-file HTML app, `index.html` is the only required file.

Create `.nojekyll` at the repository root to bypass Jekyll processing:

```text
# .nojekyll (empty file)
```

Create a minimal `.gitignore`:

```text
# .gitignore
node_modules/
*.log
.DS_Store
```

## Step 2: Create the GitHub Pages Deployment Workflow

Create `.github/workflows/deploy.yml` with the following content:

```yaml
name: Deploy to GitHub Pages

on:
  push:
    branches: [main]
  workflow_dispatch:

permissions:
  contents: read
  pages: write
  id-token: write

concurrency:
  group: "pages"
  cancel-in-progress: false

jobs:
  deploy:
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    runs-on: ubuntu-latest
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Setup Pages
        uses: actions/configure-pages@v5
      - name: Upload artifact
        uses: actions/upload-pages-artifact@v3
        with:
          path: .
      - name: Deploy to GitHub Pages
        id: deployment
        uses: actions/deploy-pages@v4
```

This workflow deploys the entire repository root as a static site.

## Step 3: Initialize the Local Git Repository

Run in the workspace directory:

```bash
git init -q
git config user.email "workbuddy@local"
git config user.name "WorkBuddy"
git add -A
git commit -m "initial commit: static html app + github pages workflow"
git branch -M main
git remote add origin https://github.com/<owner>/<repo>.git
```

Replace `<owner>` and `<repo>` with the actual GitHub owner and repository name.

> If Git is not on the user's system PATH (common on Windows machines without a standalone Git install), use the absolute path to the PortableGit binary provided by WorkBuddy, e.g.:
>
> ```powershell
> & "C:\Users\WINDOWS\.workbuddy\binaries\PortableGit\versions\1.2.0\cmd\git.exe" init -q
> ```
>
> Locate the exact `git.exe` path with:
> ```bash
> find "C:/Users/WINDOWS/.workbuddy/binaries/PortableGit" -name "git.exe"
> ```

## Step 4: Create the GitHub Repository

The user must create an empty repository on GitHub (do not initialize it with a README).

- Repository name: as configured in the remote URL (e.g., `prod-scheduler`).
- Visibility: choose **Public** if the user wants a free, shareable Pages URL. Private repositories require GitHub Enterprise for Pages.

Note: Some GitHub connector authorizations cannot create repositories via API (403). If that happens, ask the user to create the empty repository manually and then continue with the push step.

## Step 5: Push to GitHub

On the user's local machine (PowerShell, Git Bash, or CMD), run:

```bash
git push -u origin main
```

If Git Credential Manager (GCM) asks for authentication, the user should sign in with their GitHub account in the browser. After the login succeeds, the push will continue automatically.

If the user is using the absolute path to PortableGit:

```powershell
& "C:\Users\WINDOWS\.workbuddy\binaries\PortableGit\versions\1.2.0\cmd\git.exe" push -u origin main
```

> The first push may take a minute because `index.html` and the workflow file are included.

## Step 6: Enable GitHub Pages

After the push succeeds:

1. Open the repository on GitHub: `https://github.com/<owner>/<repo>`.
2. Go to **Settings → Pages**.
3. Under **Build and deployment → Source**, select **GitHub Actions**.
4. Click **Save**.

The workflow `.github/workflows/deploy.yml` will run automatically. Track progress at:

```text
https://github.com/<owner>/<repo>/actions
```

## Step 7: Verify Deployment

Wait 1-2 minutes for the Actions run to complete, then open the public Pages URL:

```text
https://<owner>.github.io/<repo>/
```

If the URL returns 404 initially, refresh after the Actions workflow shows a green checkmark.

## Common Issues and Fixes

| Symptom | Cause | Fix |
|---|---|---|
| `git: command not found` | Git not on PATH | Use absolute path to PortableGit `git.exe` |
| GCM login page shows but push still 404 | Repository does not exist or name mismatch | Verify the repository name matches the remote URL |
| `Upgrade or make this repository public to enable Pages` | Private repo on a free account | Change repository visibility to Public |
| Pages URL 404 immediately after enabling | Actions still running | Wait 1-2 minutes and refresh |

## Important Notes

- **Data persistence**: GitHub Pages is static hosting. If the app uses `localStorage` for data, each browser keeps its own copy; team members will not share data automatically.
- **Private repositories**: Pages on private repositories require GitHub Enterprise. For normal accounts, use Public visibility or upgrade.
- **Custom domains**: Add a `CNAME` file or configure a verified domain in Settings → Pages if a custom domain is needed.

## Resources

- GitHub Pages documentation: https://docs.github.com/en/pages
- Git Credential Manager: https://github.com/GitCredentialManager/git-credential-manager
